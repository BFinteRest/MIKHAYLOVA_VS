package ru.mirea.mikhaylovavs.osmmaps;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.ScaleBarOverlay;
import org.osmdroid.views.overlay.compass.CompassOverlay;
import org.osmdroid.views.overlay.compass.InternalCompassOrientationProvider;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import androidx.constraintlayout.widget.ConstraintLayout;

import ru.mirea.mikhaylovavs.osmmaps.databinding.ActivityMainBinding;
import android.preference.PreferenceManager;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private MapView mapView = null;
    private MyLocationNewOverlay locationOverlay;
    private CompassOverlay compassOverlay;
    private ScaleBarOverlay scaleBarOverlay;

    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 1;
    private static final String[] PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Инициализация osmdroid
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mapView = binding.mapView;
        mapView.setTileSource(TileSourceFactory.MAPNIK); // Используем стандартные тайлы
        mapView.setMultiTouchControls(true); // Включение мультитач
        mapView.setBuiltInZoomControls(true); // Встроенные кнопки масштабирования

        // Получаем контроллер карты
        IMapController mapController = mapView.getController();
        mapController.setZoom(15.0); // Уровень приближения

        // Устанавливаем начальную точку (Москва, МИРЭА)
        GeoPoint startPoint = new GeoPoint(55.670005, 37.479894);
        mapController.setCenter(startPoint);

        // Запрашиваем разрешения
        requestPermissionsIfNecessary();

        // Добавляем маркеры после получения разрешений
        if (hasPermissions()) {
            setupMapFeatures();
        }
    }

    private boolean hasPermissions() {
        for (String permission : PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void requestPermissionsIfNecessary() {
        if (!hasPermissions()) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupMapFeatures();
            } else {
                Toast.makeText(this, "Разрешения не предоставлены, некоторые функции могут не работать", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setupMapFeatures() {
        // 1. Определение местоположения устройства
        setupLocationOverlay();

        // 2. Добавление компаса
        setupCompassOverlay();

        // 3. Добавление метрической шкалы масштаба
        setupScaleBarOverlay();

        // 4. Добавление маркеров с обработкой нажатия
        addMarkers();
    }

    private void setupLocationOverlay() {
        // Создаем overlay для отображения местоположения
        locationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(getApplicationContext()), mapView);
        locationOverlay.enableMyLocation();
        mapView.getOverlays().add(locationOverlay);
    }

    private void setupCompassOverlay() {
        // Создаем компас
        compassOverlay = new CompassOverlay(getApplicationContext(),
                new InternalCompassOrientationProvider(getApplicationContext()), mapView);
        compassOverlay.enableCompass();
        mapView.getOverlays().add(compassOverlay);
    }

    private void setupScaleBarOverlay() {
        // Создаем шкалу масштаба
        final Context context = this.getApplicationContext();
        final DisplayMetrics dm = context.getResources().getDisplayMetrics();

        scaleBarOverlay = new ScaleBarOverlay(mapView);
        scaleBarOverlay.setCentred(true);
        scaleBarOverlay.setScaleBarOffset(dm.widthPixels / 2, 10);
        mapView.getOverlays().add(scaleBarOverlay);
    }

    private void addMarkers() {
        // Маркер 1: МИРЭА
        Marker mireaMarker = new Marker(mapView);
        mireaMarker.setPosition(new GeoPoint(55.670005, 37.479894));
        mireaMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        mireaMarker.setTitle("РТУ МИРЭА");
        mireaMarker.setSnippet("Российский технологический университет");
        mireaMarker.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker, MapView mapView) {
                Toast.makeText(MainActivity.this,
                        "РТУ МИРЭА\nВернадского 78",
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        mapView.getOverlays().add(mireaMarker);

        // Маркер 2: Красная площадь
        Marker redSquareMarker = new Marker(mapView);
        redSquareMarker.setPosition(new GeoPoint(55.753544, 37.621202));
        redSquareMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        redSquareMarker.setTitle("Красная площадь");
        redSquareMarker.setSnippet("Главная площадь Москвы");
        redSquareMarker.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker, MapView mapView) {
                Toast.makeText(MainActivity.this,
                        "Красная площадь\nИсторический центр Москвы",
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        mapView.getOverlays().add(redSquareMarker);

        // Маркер 3: Ваши координаты (Центр развития Эстет)
        Marker estetMarker = new Marker(mapView);
        estetMarker.setPosition(new GeoPoint(55.655589, 37.761796));
        estetMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        estetMarker.setTitle("Центр развития Эстет");
        estetMarker.setSnippet("Культурно-развлекательный центр");
        estetMarker.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker, MapView mapView) {
                Toast.makeText(MainActivity.this,
                        "Центр развития Эстет\nУл. Примерная, д. 1",
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        mapView.getOverlays().add(estetMarker);

        // Можно добавить иконки для маркеров
        try {
            mireaMarker.setIcon(ResourcesCompat.getDrawable(getResources(),
                    android.R.drawable.ic_dialog_info, null));
            redSquareMarker.setIcon(ResourcesCompat.getDrawable(getResources(),
                    android.R.drawable.ic_dialog_map, null));
            estetMarker.setIcon(ResourcesCompat.getDrawable(getResources(),
                    android.R.drawable.ic_dialog_dialer, null));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Важно вызывать onResume для mapView
        if (mapView != null) {
            mapView.onResume();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // Важно вызывать onPause для mapView
        if (mapView != null) {
            mapView.onPause();
        }
    }
}