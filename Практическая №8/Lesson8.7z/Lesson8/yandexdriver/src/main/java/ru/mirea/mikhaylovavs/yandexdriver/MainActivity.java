package ru.mirea.mikhaylovavs.yandexdriver;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.yandex.mapkit.Animation;
import com.yandex.mapkit.MapKitFactory;
import com.yandex.mapkit.RequestPoint;
import com.yandex.mapkit.RequestPointType;
import com.yandex.mapkit.directions.DirectionsFactory;
import com.yandex.mapkit.directions.driving.DrivingOptions;
import com.yandex.mapkit.directions.driving.DrivingRoute;
import com.yandex.mapkit.directions.driving.DrivingRouter;
import com.yandex.mapkit.directions.driving.DrivingSession;
import com.yandex.mapkit.directions.driving.VehicleOptions;
import com.yandex.mapkit.geometry.Point;
import com.yandex.mapkit.map.CameraPosition;
import com.yandex.mapkit.map.MapObjectCollection;
import com.yandex.mapkit.mapview.MapView;
import com.yandex.runtime.Error;
import com.yandex.runtime.network.NetworkError;
import com.yandex.runtime.network.RemoteError;

import java.util.ArrayList;
import java.util.List;

import ru.mirea.mikhaylovavs.yandexdriver.databinding.ActivityMainBinding;
import android.widget.Toast;
import com.yandex.mapkit.map.MapObjectTapListener;
import com.yandex.mapkit.map.PlacemarkMapObject;
import com.yandex.mapkit.map.MapObject;

public class MainActivity extends AppCompatActivity implements DrivingSession.DrivingRouteListener {
    private ActivityMainBinding binding;

    // Координаты из задания
    private final Point ROUTE_START_LOCATION = new Point(55.650759, 37.765264); // Ваши координаты
    private final Point ROUTE_END_LOCATION = new Point(55.655589, 37.761796);   // Центр развития Эстет
    private final Point SCREEN_CENTER = new Point(
            (ROUTE_START_LOCATION.getLatitude() + ROUTE_END_LOCATION.getLatitude()) / 2,
            (ROUTE_START_LOCATION.getLongitude() + ROUTE_END_LOCATION.getLongitude()) / 2
    );

    private MapView mapView;
    private MapObjectCollection mapObjects;
    private DrivingRouter drivingRouter;
    private DrivingSession drivingSession;

    // Цвета маршрутов как в методичке
    private int[] colors = {0xFFFF0000, 0xFF00FF00, 0x00FFBBBB, 0xFF0000FF};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Инициализация как в методичке
        MapKitFactory.initialize(this);
        DirectionsFactory.initialize(this);  // ВАЖНО: DirectionsFactory тоже нужно инициализировать

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mapView = binding.mapView;

        // Отключаем вращение жестами как в методичке
        mapView.getMap().setRotateGesturesEnabled(false);

        // Устанавливаем камеру
        mapView.getMap().move(
                new CameraPosition(SCREEN_CENTER, 14, 0, 0),
                new Animation(Animation.Type.SMOOTH, 0),
                null
        );

        // Получаем DrivingRouter как в методичке
        drivingRouter = DirectionsFactory.getInstance().createDrivingRouter();
        mapObjects = mapView.getMap().getMapObjects().addCollection();

        // Добавляем маркер на целевую точку (требование задания)
        addMarkerAtDestination();

        // Строим маршрут
        submitRequest();
    }

    private void submitRequest() {
        DrivingOptions drivingOptions = new DrivingOptions();
        VehicleOptions vehicleOptions = new VehicleOptions();

        // Устанавливаем количество альтернативных маршрутов
        drivingOptions.setRoutesCount(4);  // 4 маршрута как в методичке

        ArrayList<RequestPoint> requestPoints = new ArrayList<>();

        // Добавляем точки маршрута
        // Для версии 4.3.1 используется конструктор с 3 параметрами
        requestPoints.add(new RequestPoint(
                ROUTE_START_LOCATION,
                RequestPointType.WAYPOINT,
                null  // context - может быть null
        ));
        requestPoints.add(new RequestPoint(
                ROUTE_END_LOCATION,
                RequestPointType.WAYPOINT,
                null
        ));

        // Отправляем запрос на построение маршрутов
        drivingSession = drivingRouter.requestRoutes(requestPoints, drivingOptions, vehicleOptions, this);
    }

    @Override
    public void onDrivingRoutes(@NonNull List<DrivingRoute> list) {
        // Обрабатываем полученные маршруты
        for (int i = 0; i < list.size(); i++) {
            DrivingRoute route = list.get(i);
            // Рисуем маршрут на карте
            mapObjects.addPolyline(route.getGeometry()).setStrokeColor(colors[i % colors.length]);
        }

        // Показываем сообщение об успехе
        Toast.makeText(this, "Построено маршрутов: " + list.size(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDrivingRoutesError(@NonNull Error error) {
        String errorMessage = "Неизвестная ошибка";
        if (error instanceof RemoteError) {
            errorMessage = "Ошибка сервера";
        } else if (error instanceof NetworkError) {
            errorMessage = "Ошибка сети";
        }
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
    }

    private void addMarkerAtDestination() {
        // Добавляем маркер на конечную точку как в методичке
        PlacemarkMapObject marker = mapObjects.addPlacemark(ROUTE_END_LOCATION);

        // Обработка нажатия на маркер
        marker.addTapListener(new MapObjectTapListener() {
            @Override
            public boolean onMapObjectTap(@NonNull MapObject mapObject, @NonNull Point point) {
                Toast.makeText(
                        MainActivity.this,
                        "Центр развития Эстет\nКультурно-развлекательный центр",
                        Toast.LENGTH_LONG
                ).show();
                return true;
            }
        });
    }

    @Override
    protected void onStop() {
        mapView.onStop();
        MapKitFactory.getInstance().onStop();
        super.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        MapKitFactory.getInstance().onStart();
        mapView.onStart();
    }
}