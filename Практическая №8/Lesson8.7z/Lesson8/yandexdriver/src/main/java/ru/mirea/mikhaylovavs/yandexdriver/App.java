package ru.mirea.mikhaylovavs.yandexdriver;

import android.app.Application;
import com.yandex.mapkit.MapKitFactory;

public class App extends Application {
    private final String MAPKIT_API_KEY = "15f4941e-11b0-476b-83c3-56bb92069223";

    @Override
    public void onCreate() {
        super.onCreate();
        // Устанавливаем API-ключ
        MapKitFactory.setApiKey(MAPKIT_API_KEY);
    }
}