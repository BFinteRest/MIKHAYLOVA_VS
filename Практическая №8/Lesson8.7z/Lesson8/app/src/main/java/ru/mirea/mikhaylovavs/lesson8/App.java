package ru.mirea.mikhaylovavs.lesson8;

import android.app.Application;
import com.yandex.mapkit.MapKitFactory;

public class App extends Application {
    // API ключ
    private final String MAPKIT_API_KEY = "15f4941e-11b0-476b-83c3-56bb92069223";

    @Override
    public void onCreate() {
        super.onCreate();
        // Устанавливаем API ключ перед инициализацией MapKitFactory
        MapKitFactory.setApiKey(MAPKIT_API_KEY);
    }
}