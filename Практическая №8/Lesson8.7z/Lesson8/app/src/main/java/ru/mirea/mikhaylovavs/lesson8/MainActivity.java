package ru.mirea.mikhaylovavs.lesson8;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import com.yandex.mapkit.Animation;
import com.yandex.mapkit.MapKitFactory;
import com.yandex.mapkit.geometry.Point;
import com.yandex.mapkit.map.CameraPosition;
import com.yandex.mapkit.map.MapObjectTapListener;
import com.yandex.mapkit.map.PlacemarkMapObject;
import com.yandex.mapkit.mapview.MapView;
import com.yandex.runtime.image.ImageProvider;

import ru.mirea.mikhaylovavs.lesson8.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private MapView mapView;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Инициализация MapKit
        MapKitFactory.initialize(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mapView = binding.mapview;

        // Координаты Центра развития Эстет
        Point initialLocation = new Point(55.655589, 37.761796);

        // Установка начальной позиции камеры на заведение
        mapView.getMap().move(
                new CameraPosition(initialLocation, 15.0f, 0.0f, 0.0f),
                new Animation(Animation.Type.SMOOTH, 0),
                null
        );

        // Добавление маркера для задания
        addFavoritePlaceMarker();

        // Проверка и запрос разрешений для определения местоположения
        checkLocationPermission();
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            // Включаем отображение местоположения
            enableMyLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation();
            } else {
                Toast.makeText(this, "Для отображения местоположения нужны разрешения",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void enableMyLocation() {

        mapView.getMap().setRotateGesturesEnabled(false);
        mapView.getMap().getMapObjects().addPlacemark(
                new Point(55.655589, 37.761796),
                ImageProvider.fromResource(this, android.R.drawable.ic_menu_mylocation)
        );
    }

    private void addFavoritePlaceMarker() {
        // Координаты Центра развития Эстет
        Point favoritePlace = new Point(55.655589, 37.761796);

        // Создание маркера
        PlacemarkMapObject marker = mapView.getMap().getMapObjects()
                .addPlacemark(favoritePlace,
                        ImageProvider.fromResource(this, android.R.drawable.star_on));

        // Настройка внешнего вида маркера
        marker.setOpacity(0.9f);

        // Обработка нажатия на маркер
        marker.addTapListener(new MapObjectTapListener() {
            @Override
            public boolean onMapObjectTap(@NonNull com.yandex.mapkit.map.MapObject mapObject,
                                          @NonNull Point point) {
                Toast.makeText(MainActivity.this,
                        "Центр развития Эстет\n" +
                                "Адрес: ул. Примерная, д. 123\n" +
                                "Время работы: 9:00-21:00\n" +
                                "Телефон: +7 (495) 123-45-67\n" +
                                "Сайт: estet-center.ru",
                        Toast.LENGTH_LONG).show();
                return true;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        MapKitFactory.getInstance().onStart();
        mapView.onStart();
    }

    @Override
    protected void onStop() {
        mapView.onStop();
        MapKitFactory.getInstance().onStop();
        super.onStop();
    }
}