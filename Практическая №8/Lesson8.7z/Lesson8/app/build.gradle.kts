plugins {
    id("com.android.application")
}

android {
    namespace = "ru.mirea.mikhaylovavs.lesson8"
    compileSdk = 36

    defaultConfig {
        applicationId = "ru.mirea.mikhaylovavs.lesson8"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // Yandex MapKit
    implementation("com.yandex.android:maps.mobile:4.3.1-lite")
}

configurations.all {
    resolutionStrategy {
        // Принудительно используем одну версию Kotlin
        force("org.jetbrains.kotlin:kotlin-stdlib:1.8.22")
        force("org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.22")
        force("org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.22")

        // Удаляем старые версии если есть
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk7:1.6.21")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk8:1.6.21")
    }
}