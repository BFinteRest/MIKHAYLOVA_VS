package ru.mirea.MikhaylovaVS.controllesson1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button button2, button3, button4, button5, button6, button7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Получаем ссылки на элементы
        editText = findViewById(R.id.editTextText);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);

        // Меняем свойства элементов
        editText.setText("Привет! Это Владлена");
        editText.setTextColor(Color.RED);

        button2.setText("Первая кнопка");
        button3.setText("Вторая кнопка");
        button4.setText("Третья кнопка");
        button5.setText("Четвертая кнопка");
        button6.setText("Пятая кнопка");
        button7.setText("Шестая кнопка");

        button2.setTextColor(Color.YELLOW);
        button3.setTextColor(Color.BLACK);
        button4.setTextColor(Color.YELLOW);
        button5.setTextColor(Color.WHITE);
        button6.setTextColor(Color.BLUE);
        button7.setTextColor(Color.RED);

        button2.setTextSize(16);
        button3.setTextSize(16);
        button4.setTextSize(16);
        button5.setTextSize(16);
        button6.setTextSize(16);
        button7.setTextSize(16);

        // ========== ОБРАБОТЧИКИ СОБЫТИЙ ==========

        // Обработчик для первой кнопки - меняет текст в EditText
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("Вы нажали первую кнопку!");
                editText.setTextColor(Color.BLUE);
                Toast.makeText(MainActivity.this,
                        "Первая кнопка нажата!", Toast.LENGTH_SHORT).show();
            }
        });

        // Обработчик для второй кнопки - меняет цвет фона
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Меняем цвет фона EditText
                editText.setBackgroundColor(Color.CYAN);
                button3.setText("Цвет изменен!");
                Toast.makeText(MainActivity.this,
                        "Фон изменен на голубой", Toast.LENGTH_SHORT).show();
            }
        });

        // Обработчик для третьей кнопки - меняет текст всех кнопок
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button2.setText("Кнопка 6");
                button3.setText("Кнопка 5");
                button4.setText("Кнопка 4");
                button5.setText("Кнопка 3");
                button6.setText("Кнопка 2");
                button7.setText("Кнопка 1");
                editText.setText("Все кнопки переименованы!");
            }
        });

        // Обработчик для четвертой кнопки - показывает/скрывает кнопки
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (button6.getVisibility() == View.VISIBLE) {
                    // Скрываем кнопки 6 и 7
                    button6.setVisibility(View.INVISIBLE);
                    button7.setVisibility(View.INVISIBLE);
                    button5.setText("Показать кнопки");
                    editText.setText("Кнопки 6 и 7 скрыты");
                } else {
                    // Показываем кнопки 6 и 7
                    button6.setVisibility(View.VISIBLE);
                    button7.setVisibility(View.VISIBLE);
                    button5.setText("Скрыть кнопки");
                    editText.setText("Кнопки 6 и 7 показаны");
                }
            }
        });

        // Обработчик для пятой кнопки - сброс всех изменений
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("Привет! Это Владлена");
                editText.setTextColor(Color.RED);
                editText.setBackgroundColor(Color.TRANSPARENT);

                // Показываем все кнопки
                button6.setVisibility(View.VISIBLE);
                button7.setVisibility(View.VISIBLE);

                Toast.makeText(MainActivity.this,
                        "Все сброшено!", Toast.LENGTH_SHORT).show();
            }
        });

        // Обработчик для шестой кнопки - меняет размер текста
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Увеличиваем размер текста
                button2.setTextSize(20);
                button3.setTextSize(20);
                button4.setTextSize(20);
                button5.setTextSize(20);
                button6.setTextSize(20);
                button7.setTextSize(20);

                editText.setText("Размер текста увеличен!");
                editText.setTextSize(24);
            }
        });
    }
}