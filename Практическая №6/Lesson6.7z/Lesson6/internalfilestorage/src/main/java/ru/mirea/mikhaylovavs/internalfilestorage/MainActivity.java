package ru.mirea.mikhaylovavs.internalfilestorage;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    private EditText editTextDateTitle, editTextDateDescription;
    private Button buttonSaveToFile, buttonReadFromFile;
    private TextView textViewFileContent, textViewFilePath;

    private static final String FILE_NAME = "historical_date.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов интерфейса
        editTextDateTitle = findViewById(R.id.editTextDateTitle);
        editTextDateDescription = findViewById(R.id.editTextDateDescription);
        buttonSaveToFile = findViewById(R.id.buttonSaveToFile);
        buttonReadFromFile = findViewById(R.id.buttonReadFromFile);
        textViewFileContent = findViewById(R.id.textViewFileContent);
        textViewFilePath = findViewById(R.id.textViewFilePath);

        // Показать путь к файлу
        showFilePath();

        // Обработчик кнопки сохранения
        buttonSaveToFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToFile();
            }
        });

        // Обработчик кнопки чтения
        buttonReadFromFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readFromFile();
            }
        });
    }

    private void showFilePath() {
        // Показываем путь к файлу во внутреннем хранилище
        String filePath = getFilesDir() + "/" + FILE_NAME;
        textViewFilePath.setText("Файл будет сохранен в:\n" + filePath);
    }

    private void saveToFile() {
        String dateTitle = editTextDateTitle.getText().toString().trim();
        String dateDescription = editTextDateDescription.getText().toString().trim();

        if (dateTitle.isEmpty() || dateDescription.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        // Формируем содержимое файла
        String content = "Памятная дата: " + dateTitle + "\n\n" +
                "Описание:\n" + dateDescription + "\n\n" +
                "Записано: " + java.time.LocalDate.now();

        try {
            // Открываем поток для записи во внутреннее хранилище
            FileOutputStream fileOutputStream = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            OutputStreamWriter outputWriter = new OutputStreamWriter(fileOutputStream);

            // Записываем данные
            outputWriter.write(content);
            outputWriter.close();

            Toast.makeText(this, "Данные сохранены в файл", Toast.LENGTH_SHORT).show();

            // Очищаем поля после сохранения
            editTextDateTitle.setText("");
            editTextDateDescription.setText("");

            // Обновляем информацию о файле
            showFilePath();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка сохранения файла: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void readFromFile() {
        try {
            // Открываем поток для чтения из внутреннего хранилища
            FileInputStream fileInputStream = openFileInput(FILE_NAME);
            InputStreamReader inputReader = new InputStreamReader(fileInputStream);

            // Читаем данные
            char[] buffer = new char[1024];
            StringBuilder content = new StringBuilder();
            int charsRead;

            while ((charsRead = inputReader.read(buffer)) > 0) {
                content.append(buffer, 0, charsRead);
            }

            inputReader.close();

            // Отображаем прочитанные данные
            textViewFileContent.setText(content.toString());
            Toast.makeText(this, "Данные загружены из файла", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
            textViewFileContent.setText("Файл не найден или ошибка чтения");
            Toast.makeText(this, "Файл не найден. Сначала сохраните данные", Toast.LENGTH_SHORT).show();
        }
    }

    // Метод для получения списка файлов (дополнительно)
    private void listFiles() {
        String[] files = fileList();
        StringBuilder fileList = new StringBuilder("Файлы в директории:\n");

        for (String file : files) {
            fileList.append("- ").append(file).append("\n");
        }

        Toast.makeText(this, fileList.toString(), Toast.LENGTH_LONG).show();
    }
}