package ru.mirea.mikhaylovavs.lesson6;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextGroup, editTextNumber, editTextMovie;
    private Button buttonSave;
    private SharedPreferences sharedPreferences;

    private static final String PREFS_NAME = "mirea_settings";
    private static final String KEY_GROUP = "GROUP";
    private static final String KEY_NUMBER = "NUMBER";
    private static final String KEY_MOVIE = "MOVIE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Находим элементы интерфейса
        editTextGroup = findViewById(R.id.editTextGroup);
        editTextNumber = findViewById(R.id.editTextNumber);
        editTextMovie = findViewById(R.id.editTextMovie);
        buttonSave = findViewById(R.id.buttonSave);

        // Загружаем сохраненные значения
        loadData();

        // Обработчик кнопки сохранения
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });
    }

    private void saveData() {
        String group = editTextGroup.getText().toString();
        String numberStr = editTextNumber.getText().toString();
        String movie = editTextMovie.getText().toString();

        // Проверка заполнения полей
        if (group.isEmpty() || numberStr.isEmpty() || movie.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        int number = Integer.parseInt(numberStr);

        // Сохраняем данные в SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_GROUP, group);
        editor.putInt(KEY_NUMBER, number);
        editor.putString(KEY_MOVIE, movie);
        editor.apply();

        Toast.makeText(this, "Данные сохранены", Toast.LENGTH_SHORT).show();
    }

    private void loadData() {
        // Загружаем сохраненные значения
        String group = sharedPreferences.getString(KEY_GROUP, "");
        int number = sharedPreferences.getInt(KEY_NUMBER, 0);
        String movie = sharedPreferences.getString(KEY_MOVIE, "");

        // Устанавливаем значения в поля ввода
        editTextGroup.setText(group);
        editTextNumber.setText(number > 0 ? String.valueOf(number) : "");
        editTextMovie.setText(movie);
    }
}