package ru.mirea.mikhaylovavs.employeedb;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "superheroes")
public class SuperHero {
    @PrimaryKey(autoGenerate = true)
    public long id;

    public String name;
    public String superpower;
    public int powerLevel;

    // Конструктор по умолчанию (нужен для Room)
    public SuperHero() {
    }

    public SuperHero(String name, String superpower, int powerLevel) {
        this.name = name;
        this.superpower = superpower;
        this.powerLevel = powerLevel;
    }

    @Override
    public String toString() {
        return "ID: " + id +
                "\nИмя: " + name +
                "\nСуперспособность: " + superpower +
                "\nУровень силы: " + powerLevel +
                "\n---";
    }
}