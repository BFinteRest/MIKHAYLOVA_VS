package ru.mirea.mikhaylovavs.employeedb;

import android.app.Application;
import androidx.room.Room;

public class App extends Application {

    private static App instance;
    private AppDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Создание базы данных
        database = Room.databaseBuilder(this, AppDatabase.class, "superhero-database")
                .allowMainThreadQueries()
                .build();
    }

    public static App getInstance() {
        return instance;
    }

    public AppDatabase getDatabase() {
        return database;
    }
}