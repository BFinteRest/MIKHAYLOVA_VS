package ru.mirea.mikhaylovavs.employeedb;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextSuperpower, editTextPowerLevel, editTextId;
    private Button buttonAdd, buttonGetAll, buttonClear, buttonGetById, buttonDelete;
    private TextView textViewResult, textViewDbInfo;

    private AppDatabase database;
    private SuperHeroDao superHeroDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация базы данных
        database = App.getInstance().getDatabase();
        superHeroDao = database.superHeroDao();

        initViews();
        setClickListeners();
        updateDatabaseInfo();
    }

    private void initViews() {
        editTextName = findViewById(R.id.editTextName);
        editTextSuperpower = findViewById(R.id.editTextSuperpower);
        editTextPowerLevel = findViewById(R.id.editTextPowerLevel);
        editTextId = findViewById(R.id.editTextId);

        buttonAdd = findViewById(R.id.buttonAdd);
        buttonGetAll = findViewById(R.id.buttonGetAll);
        buttonClear = findViewById(R.id.buttonClear);
        buttonGetById = findViewById(R.id.buttonGetById);
        buttonDelete = findViewById(R.id.buttonDelete);

        textViewResult = findViewById(R.id.textViewResult);
        textViewDbInfo = findViewById(R.id.textViewDbInfo);
    }

    private void setClickListeners() {
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSuperHero();
            }
        });

        buttonGetAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAllSuperHeroes();
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearDatabase();
            }
        });

        buttonGetById.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSuperHeroById();
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSuperHeroById();
            }
        });
    }

    private void updateDatabaseInfo() {
        int count = superHeroDao.getCount();
        textViewDbInfo.setText("В базе данных: " + count + " супер-героев");
    }

    private void addSuperHero() {
        String name = editTextName.getText().toString().trim();
        String superpower = editTextSuperpower.getText().toString().trim();
        String powerLevelStr = editTextPowerLevel.getText().toString().trim();

        if (name.isEmpty() || superpower.isEmpty() || powerLevelStr.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int powerLevel = Integer.parseInt(powerLevelStr);

            if (powerLevel < 1 || powerLevel > 100) {
                Toast.makeText(this, "Уровень силы должен быть от 1 до 100", Toast.LENGTH_SHORT).show();
                return;
            }

            SuperHero hero = new SuperHero(name, superpower, powerLevel);
            superHeroDao.insert(hero);

            Toast.makeText(this, "Супер-герой добавлен!", Toast.LENGTH_SHORT).show();

            // Очищаем поля
            editTextName.setText("");
            editTextSuperpower.setText("");
            editTextPowerLevel.setText("");

            // Обновляем информацию
            updateDatabaseInfo();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Введите корректный уровень силы", Toast.LENGTH_SHORT).show();
        }
    }

    private void getAllSuperHeroes() {
        List<SuperHero> heroes = superHeroDao.getAll();

        if (heroes.isEmpty()) {
            textViewResult.setText("База данных пуста");
            return;
        }

        StringBuilder result = new StringBuilder("Все супер-герои:\n\n");
        for (SuperHero hero : heroes) {
            result.append(hero.toString()).append("\n");
        }

        textViewResult.setText(result.toString());
    }

    private void getSuperHeroById() {
        String idStr = editTextId.getText().toString().trim();

        if (idStr.isEmpty()) {
            Toast.makeText(this, "Введите ID героя", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            long id = Long.parseLong(idStr);
            SuperHero hero = superHeroDao.getById(id);

            if (hero == null) {
                textViewResult.setText("Герой с ID " + id + " не найден");
            } else {
                textViewResult.setText("Найден герой:\n\n" + hero.toString());
            }

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Введите корректный ID", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteSuperHeroById() {
        String idStr = editTextId.getText().toString().trim();

        if (idStr.isEmpty()) {
            Toast.makeText(this, "Введите ID героя", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            long id = Long.parseLong(idStr);
            SuperHero hero = superHeroDao.getById(id);

            if (hero == null) {
                Toast.makeText(this, "Герой с ID " + id + " не найден", Toast.LENGTH_SHORT).show();
                return;
            }

            superHeroDao.delete(hero);
            Toast.makeText(this, "Герой с ID " + id + " удален", Toast.LENGTH_SHORT).show();

            // Очищаем поле ID
            editTextId.setText("");

            // Обновляем информацию
            updateDatabaseInfo();
            getAllSuperHeroes();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Введите корректный ID", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearDatabase() {
        superHeroDao.deleteAll();
        Toast.makeText(this, "База данных очищена", Toast.LENGTH_SHORT).show();
        textViewResult.setText("База данных пуста");
        updateDatabaseInfo();
    }
}