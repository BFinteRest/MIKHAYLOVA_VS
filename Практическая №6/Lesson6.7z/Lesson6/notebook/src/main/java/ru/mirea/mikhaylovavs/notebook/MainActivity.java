package ru.mirea.mikhaylovavs.notebook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextFileName, editTextQuote;
    private Button buttonSave, buttonLoad, buttonListFiles;
    private TextView textViewInfo, textViewLoadedQuote, textViewFileList;

    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов интерфейса
        editTextFileName = findViewById(R.id.editTextFileName);
        editTextQuote = findViewById(R.id.editTextQuote);
        buttonSave = findViewById(R.id.buttonSave);
        buttonLoad = findViewById(R.id.buttonLoad);
        buttonListFiles = findViewById(R.id.buttonListFiles);
        textViewInfo = findViewById(R.id.textViewInfo);
        textViewLoadedQuote = findViewById(R.id.textViewLoadedQuote);
        textViewFileList = findViewById(R.id.textViewFileList);

        // Проверка и запрос разрешений
        checkAndRequestPermissions();

        // Обработчики кнопок
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveQuoteToFile();
            }
        });

        buttonLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadQuoteFromFile();
            }
        });

        buttonListFiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listSavedFiles();
            }
        });

        // Показываем информацию о директории
        showStorageInfo();
    }

    private void checkAndRequestPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        // Проверяем разрешение на запись
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        // Для Android 11+ нужно MANAGE_EXTERNAL_STORAGE
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                permissionsNeeded.add(Manifest.permission.MANAGE_EXTERNAL_STORAGE);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    permissionsNeeded.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE);
        }
    }

    private void showStorageInfo() {
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            textViewInfo.setText("Внешнее хранилище доступно для чтения и записи");
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            textViewInfo.setText("Внешнее хранилище доступно только для чтения");
        } else {
            textViewInfo.setText("Внешнее хранилище недоступно");
        }
    }

    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private void saveQuoteToFile() {
        if (!isExternalStorageWritable()) {
            Toast.makeText(this, "Внешнее хранилище недоступно для записи", Toast.LENGTH_SHORT).show();
            return;
        }

        String fileName = editTextFileName.getText().toString().trim();
        String quote = editTextQuote.getText().toString().trim();

        if (fileName.isEmpty() || quote.isEmpty()) {
            Toast.makeText(this, "Заполните название файла и цитату", Toast.LENGTH_SHORT).show();
            return;
        }

        // Добавляем расширение .txt если его нет
        if (!fileName.endsWith(".txt")) {
            fileName += ".txt";
        }

        try {
            // Получаем путь к публичной директории Documents
            File documentsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);

            // Создаем директорию, если ее нет
            if (!documentsDir.exists()) {
                documentsDir.mkdirs();
            }

            // Создаем файл
            File file = new File(documentsDir, fileName);

            // Записываем данные в файл
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            OutputStreamWriter writer = new OutputStreamWriter(fileOutputStream);

            writer.write(quote);
            writer.close();

            Toast.makeText(this, "Цитата сохранена в файл: " + fileName, Toast.LENGTH_LONG).show();

            // Очищаем поля
            editTextFileName.setText("");
            editTextQuote.setText("");

            // Показываем информацию о сохранении
            textViewInfo.setText("Файл сохранен: " + file.getAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка сохранения файла: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void loadQuoteFromFile() {
        if (!isExternalStorageWritable()) {
            Toast.makeText(this, "Внешнее хранилище недоступно", Toast.LENGTH_SHORT).show();
            return;
        }

        String fileName = editTextFileName.getText().toString().trim();

        if (fileName.isEmpty()) {
            Toast.makeText(this, "Введите название файла", Toast.LENGTH_SHORT).show();
            return;
        }

        // Добавляем расширение .txt если его нет
        if (!fileName.endsWith(".txt")) {
            fileName += ".txt";
        }

        try {
            // Получаем путь к файлу в Documents
            File documentsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            File file = new File(documentsDir, fileName);

            if (!file.exists()) {
                Toast.makeText(this, "Файл не найден: " + fileName, Toast.LENGTH_SHORT).show();
                return;
            }

            // Читаем данные из файла
            FileInputStream fileInputStream = new FileInputStream(file);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader reader = new BufferedReader(inputStreamReader);

            StringBuilder content = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }

            reader.close();

            // Отображаем загруженную цитату
            textViewLoadedQuote.setText(content.toString());
            Toast.makeText(this, "Цитата загружена из файла: " + fileName, Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка чтения файла: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void listSavedFiles() {
        File documentsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);

        if (!documentsDir.exists() || !documentsDir.isDirectory()) {
            textViewFileList.setText("Директория Documents не найдена");
            return;
        }

        File[] files = documentsDir.listFiles();

        if (files == null || files.length == 0) {
            textViewFileList.setText("В директории Documents нет файлов");
            return;
        }

        StringBuilder fileList = new StringBuilder("Сохраненные файлы:\n\n");

        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".txt")) {
                fileList.append("• ").append(file.getName()).append("\n");
                fileList.append("  Размер: ").append(file.length()).append(" байт\n");
                fileList.append("  Путь: ").append(file.getAbsolutePath()).append("\n\n");
            }
        }

        textViewFileList.setText(fileList.toString());
    }
}