package ru.mirea.mikhaylovavs.securesharedpreferences;

import androidx.appcompat.app.AppCompatActivity;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPoet;
    private Button buttonSave, buttonLoad;
    private TextView textViewResult;

    private static final String PREFS_NAME = "secret_shared_prefs";
    private static final String KEY_POET = "favorite_poet";
    private SharedPreferences secureSharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPoet = findViewById(R.id.editTextPoet);
        buttonSave = findViewById(R.id.buttonSave);
        buttonLoad = findViewById(R.id.buttonLoad);
        textViewResult = findViewById(R.id.textViewResult);

        initEncryptedPreferences();

        buttonSave.setOnClickListener(v -> saveData());
        buttonLoad.setOnClickListener(v -> loadData());
    }

    private void initEncryptedPreferences() {
        try {
            String masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);

            secureSharedPreferences = EncryptedSharedPreferences.create(
                    PREFS_NAME,
                    masterKeyAlias,
                    getApplicationContext(),
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );

            Toast.makeText(this, "Безопасное хранилище инициализировано", Toast.LENGTH_SHORT).show();

        } catch (GeneralSecurityException | IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка инициализации", Toast.LENGTH_LONG).show();
        }
    }

    private void saveData() {
        String poetName = editTextPoet.getText().toString().trim();

        if (poetName.isEmpty()) {
            Toast.makeText(this, "Введите имя поэта", Toast.LENGTH_SHORT).show();
            return;
        }

        if (secureSharedPreferences != null) {
            secureSharedPreferences.edit()
                    .putString(KEY_POET, poetName)
                    .apply();

            Toast.makeText(this, "Данные сохранены безопасно", Toast.LENGTH_SHORT).show();
            editTextPoet.setText("");
        }
    }

    private void loadData() {
        if (secureSharedPreferences != null) {
            String savedPoet = secureSharedPreferences.getString(KEY_POET, "Данные не найдены");
            textViewResult.setText("Любимый поэт: " + savedPoet);
        }
    }
}