plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "ru.mirea.mikhaylovavs.securesharedpreferences"

    // ОБНОВЛЕНО: Используем версию 36 как рекомендует Android Studio
    compileSdk = 36

    defaultConfig {
        applicationId = "ru.mirea.mikhaylovavs.securesharedpreferences"
        minSdk = 26
        targetSdk = 36  // Тоже обновляем до 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // ДОБАВЬТЕ ЭТУ ЗАВИСИМОСТЬ для EncryptedSharedPreferences
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Опционально: для загрузки изображений
    implementation("com.github.bumptech.glide:glide:4.16.0")

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}