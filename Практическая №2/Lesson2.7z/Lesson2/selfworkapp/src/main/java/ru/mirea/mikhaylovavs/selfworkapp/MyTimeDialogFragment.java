package ru.mirea.mikhaylovavs.selfworkapp;

import android.app.TimePickerDialog;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class MyTimeDialogFragment extends DialogFragment implements TimePickerDialog.OnTimeSetListener {

    @Override
    public android.app.Dialog onCreateDialog(android.os.Bundle savedInstanceState) {
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        return new TimePickerDialog(getActivity(), this, hour, minute, true);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Toast.makeText(getActivity(),
                "Выбрано время: " + hourOfDay + ":" + minute,
                Toast.LENGTH_SHORT).show();
    }
}