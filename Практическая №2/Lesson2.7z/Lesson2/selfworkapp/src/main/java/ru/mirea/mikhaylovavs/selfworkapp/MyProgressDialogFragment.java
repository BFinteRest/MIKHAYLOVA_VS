package ru.mirea.mikhaylovavs.selfworkapp;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;  // ← ДОБАВИТЬ ЭТУ СТРОЧКУ

import androidx.fragment.app.DialogFragment;

public class MyProgressDialogFragment extends DialogFragment {

    @Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setTitle("Прогресс");
        progressDialog.setMessage("Загрузка...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setMax(100);
        progressDialog.setCancelable(false);

        // Симуляция загрузки
        new Thread(() -> {
            for (int i = 0; i <= 100; i += 10) {
                try {
                    Thread.sleep(300);
                    int finalI = i;
                    new Handler(Looper.getMainLooper()).post(() -> {
                        progressDialog.setProgress(finalI);
                        if (finalI == 100) {
                            progressDialog.dismiss();
                            Toast.makeText(getActivity(),
                                    "Загрузка завершена!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        return progressDialog;
    }
}