package ru.mirea.mikhaylovavs.multiactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private static final String TAG = "MultiActivity";
    private TextView textViewReceived;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textViewReceived = findViewById(R.id.textViewReceived);
        Log.d(TAG, "SecondActivity: onCreate()");

        // ПОЛУЧАЕМ ДАННЫЕ из Intent
        // getIntent() - получаем Intent, который запустил эту Activity
        // getStringExtra("key") - получаем строку по ключу "key"
        String receivedText = getIntent().getStringExtra("key");

        if (receivedText != null && !receivedText.isEmpty()) {
            // Отображаем полученный текст
            textViewReceived.setText("Получено: " + receivedText);
            Log.d(TAG, "SecondActivity: Получен текст: " + receivedText);
        } else {
            textViewReceived.setText("Данные не получены");
            Log.d(TAG, "SecondActivity: Данные не получены");
        }
    }

    // Обработчик кнопки "Назад" (из XML)
    public void onClickBack(View view) {
        // Закрываем текущую Activity и возвращаемся к предыдущей
        finish();
        Log.d(TAG, "SecondActivity: Нажата кнопка Назад");
    }

    // Методы жизненного цикла
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "SecondActivity: onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "SecondActivity: onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "SecondActivity: onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "SecondActivity: onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "SecondActivity: onDestroy()");
    }
}