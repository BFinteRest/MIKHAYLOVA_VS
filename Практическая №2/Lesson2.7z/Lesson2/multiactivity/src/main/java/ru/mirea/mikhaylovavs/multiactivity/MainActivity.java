package ru.mirea.mikhaylovavs.multiactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MultiActivity";
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        Log.d(TAG, "MainActivity: onCreate()");
    }

    // Обработчик нажатия кнопки (указан в XML: android:onClick="onClickSend")
    public void onClickSend(View view) {
        // Получаем текст из EditText
        String textToSend = editText.getText().toString();

        // Если поле пустое, отправляем текст по умолчанию
        if (textToSend.isEmpty()) {
            textToSend = "MIREA - Михайлова В.С.";
        }

        // СОЗДАЕМ НАМЕРЕНИЕ (Intent) для перехода на SecondActivity
        // this - текущая Activity (контекст)
        // SecondActivity.class - класс, который хотим запустить
        Intent intent = new Intent(this, SecondActivity.class);

        // ПЕРЕДАЕМ ДАННЫЕ через Intent
        // "key" - ключ (может быть любой строкой)
        // textToSend - значение (то, что передаем)
        intent.putExtra("key", textToSend);

        // ЗАПУСКАЕМ SecondActivity
        startActivity(intent);

        Log.d(TAG, "MainActivity: Отправлен текст: " + textToSend);
    }

    // Методы жизненного цикла для отслеживания
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "MainActivity: onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity: onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity: onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "MainActivity: onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity: onDestroy()");
    }
}