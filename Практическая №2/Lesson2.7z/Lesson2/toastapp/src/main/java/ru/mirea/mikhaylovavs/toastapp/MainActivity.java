package ru.mirea.mikhaylovavs.toastapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
    }

    // Обработчик нажатия кнопки
    public void onClickShowToast(View view) {
        // Получаем текст из EditText
        String text = editText.getText().toString();

        // Подсчитываем количество символов
        int characterCount = text.length();

        // Формируем сообщение по шаблону из методички
        String message = "СТУДЕНТ №9 ГРУППА БИСО-02-21 Количество символов - " + characterCount;

        // Создаем и показываем Toast
        // Toast.LENGTH_SHORT - короткое отображение (2 секунды)
        // Toast.LENGTH_LONG - длинное отображение (3.5 секунды)
        Toast toast = Toast.makeText(getApplicationContext(),
                message,
                Toast.LENGTH_SHORT);

        // Показываем Toast
        toast.show();

        // Альтернативный короткий вариант (в одну строку):
        // Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}