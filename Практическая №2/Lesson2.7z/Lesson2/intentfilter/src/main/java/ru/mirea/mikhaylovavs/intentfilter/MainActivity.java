package ru.mirea.mikhaylovavs.intentfilter;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Метод для первой кнопки - ТОЧНО как в методичке
    public void onClickOpenBrowser(View view) {
        // Строка в точности из методички
        Uri address = Uri.parse("https://www.mirea.ru/");
        Intent openLinkIntent = new Intent(Intent.ACTION_VIEW, address);
        startActivity(openLinkIntent);
    }

    // Метод для второй кнопки - ТОЧНО как в методичке
    public void onClickShareFIO(View view) {
        // Строки в точности из методички
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "MIREA");
        // ЗАМЕНИТЕ на ваше ФИО!
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Михайлова Владлена Сергеевна");
        startActivity(Intent.createChooser(shareIntent, "МОИ ФИО"));
    }
}