package ru.mirea.mikhaylovavs.dialogapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

public class MyDialogFragment extends DialogFragment {

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Диалоговое окно")
                .setMessage("Привет, МИРЭА! Успех близок?")
                .setIcon(R.mipmap.ic_launcher_round)
                .setPositiveButton("Дальше", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Действие при нажатии "Дальше"
                        ((MainActivity) getActivity()).onOkClicked();
                        dialog.dismiss();
                    }
                })
                .setNeutralButton("Отмена", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Действие при нажатии "Отмена"
                        ((MainActivity) getActivity()).onNeutralClicked();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Действие при нажатии "Нет"
                        ((MainActivity) getActivity()).onCancelClicked();
                        dialog.dismiss();
                    }
                });
        return builder.create();
    }
}